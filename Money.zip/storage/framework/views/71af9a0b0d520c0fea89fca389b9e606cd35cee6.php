<script>

</script>

<?php $__env->startSection('content'); ?>
<div class="container col-md col-md-4 col-md-offset-4" style="margin-top:25vh;">
<legend>Reset Password</legend>
<center>
<?php if(isset($success)): ?>
    <p style="color:green"><span class="glyphicon glyphicon-ok"></span> <?php echo e($success); ?></p>
<?php endif; ?>
<?php if(isset($error)): ?>
    <p style="color:red"></span> <?php echo e($error); ?></p>
<?php endif; ?>
</center>
    <form action="/resetpassword" method="POST">
    <?php echo e(csrf_field()); ?>

        <div class="form-group">
        <label>Enter OTP</label>
            <input type="number" class="form-control" name="otp" placeholder="Enter OTP">
        </div>
        <div class="form-group">
        <label>Enter New Password</label>
            <input type="password" class="form-control" name="password" placeholder="Enter Password">
        </div>
        <div class="form-group">
        <label>Retype your Password</label>
            <input type="password" class="form-control" name="cpassword" placeholder="Enter Confirm Password">
        </div>
        <center>
        <button type="submit" class="btn" style="background-color:#660033;color: #F0E68C;"> &nbsp;&nbsp;&nbsp;&nbsp;Submit&nbsp;&nbsp; &nbsp;&nbsp;</button>
        </center>
    </form><br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>