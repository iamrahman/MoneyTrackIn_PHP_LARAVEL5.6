<?php $__env->startSection('content'); ?>
<?php
$type = array("Credit", "Debit");
?>
<style>
h3{
    color:white;
}
ul li{
    list-style:none;
}
#snav{
    width:100%;
    margin-left:-40px;
    margin-bottom:2px;
}
#dmenu{
  width:30%;
  height: 40px;
}
#dmenu:hover{
  box-shadow: 2px 2px 2px black;
}
table th {
    width: auto !important;
}
td {
  font-size: 12px;
}
</style>

<!-- #######################   Profile Division      #################### -->
<div class="col-md-9 col-sm-8" style="background-color: white; height: auto;">
<br>
<center>
<div class="col-md-12 table-responsive" style="width:100%;">      
<table class="table responsive table-striped">
    <thead style="background-color:#660033;">
      <tr style="color: white;">
        <th>Transaction History</th>
        <th></th><th></th><th></th><th></th><th></th><th></th>
      </tr>
    </thead>
    <tr>
        <th>Date & Time</th>
        <th>Transaction ID</th>
        <th>Account Name</th>
        <th>Amount</th>
        <th>Type</th>
        <th>Description</th>
        <th>Tags</th>
      </tr>
    <tbody>
    <?php $total =0;
    foreach ($accounts_data as $user)
    {
      $total= $total+$user['current_balance'];
    }
    ?>
    <?php $__currentLoopData = $transaction_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($user->date); ?></td>
        <td>TRAN00<?php echo e($user->id); ?></td>
        <td><?php echo e($user->account_name); ?></td>
        <td>$ <?php echo e($user->amount); ?></td>
        <?php if($type[$user->type]=="Debit"): ?>
        <td style="color:red;"><?php echo e($type[$user->type]); ?></td>
        <?php else: ?>
        <td style="color:darkgreen;"><?php echo e($type[$user->type]); ?></td>
        <?php endif; ?>
        <td><?php echo e($user->description); ?></td>
        <td><?php echo e($user->tags); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php echo e($transaction_data->links()); ?>

</center>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>