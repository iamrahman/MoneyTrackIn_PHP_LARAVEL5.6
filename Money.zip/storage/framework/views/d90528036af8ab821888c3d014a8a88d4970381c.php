<?php $__env->startSection('content'); ?>


<style>
h3{
    color:white;
}
ul li{
    list-style:none;
}
#snav{
    width:100%;
    margin-left:-40px;
    margin-bottom:2px;
}

</style>


<!-- #######################   Profile Division      #################### -->
<div class="col-md-9" style="background-color: white; height: 96vh;">
<br>
<div class="col-md-8 col-md-offset-2" style="background-color: white;box-shadow:1px 1px 5px black; height: auto;">
<center>
<img src="https://cdn3.iconfinder.com/data/icons/office-24/100/Icon_FastSetting2-512.png" style="width:12%;">
<h4>Periodic Transaction</h4>
<center>
<?php if($message = Session::get('success')): ?>
    <p style="color:green"><span class="glyphicon glyphicon-ok"></span> <?php echo e($message); ?></p>
    <script> myFun();</script>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
    <p style="color:red"><span class="glyphicon glyphicon-remove"></span> <?php echo e($message); ?></p>
<?php endif; ?>
</center>
<hr>
</center>
<form action="/periodicTransaction" method="POST">
    <?php echo e(csrf_field()); ?>

  <div class="form-group col-md-8 col-md-offset-2">
    <label for="account">Select Account</label>
    <select class="form-control" name="account">
    <option>Select</option>
    <?php $__currentLoopData = $accounts_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div><br>
  <div class="form-group col-md-8 col-md-offset-2">
    <label for="account">Time Span: </label>
    <select class="form-control" name="time_span">
    <option value="">Select</option>
    <option value="1">1 Hours</option>
    <option value="2">24 Hours</option>
    <option value="3">1 Week</option>
    <option value="4">1 months</option>
    <option value="5">6 months</option>
    <option value="6">1 Years</option>
    </select>
  </div><br>
  <div class="form-group col-md-8 col-md-offset-2">
    <label id="aid">Amount</label>
    <input type="number" class="form-control" name="amount" placeholder="Enter Amount">
  </div>
  <div class="form-group col-md-8 col-md-offset-2">
    <label id="tid">Description</label>
    <textarea type="text" id="did" class="form-control" name="description" placeholder="Enter description" required></textarea>
  </div>
  <div class="form-group col-md-8 col-md-offset-2">
    <label id="tid">Tags</label>
    <input type="text" id="textid" pattern="[a-z]+([,]+[a-z]+([a-z])?)*" class="form-control" name="tags" title="Seprate the tags with comma and lowercase only.Eg. health,vehicle" placeholder="Enter tags in lower case only using comma. Eg. food,health,vehicle" required>
  </div>

  <center>
  <div class="form-group col-md-8 col-md-offset-5">
  <button type="submit" style="float:left; width:30%;" class="btn btn-success">Submit</button>
  </div>
  </center>
</form>
<br><br>

</div>

</div>
</div><?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>