<?php $__env->startSection('content'); ?>


<style>
h3{
    color:white;
}
ul li{
    list-style:none;
}
#snav{
    width:100%;
    margin-left:-40px;
    margin-bottom:2px;
}

</style>

<!-- #######################   Profile Division      #################### -->
<div class="col-md-9 col-sm-8" style="background-color: white; height: 100vh;"><br><br>
<div class="col-md-8 col-md-offset-2" style="background-color: white;box-shadow:1px 1px 5px black; height: auto;">
<center>
<img src="https://cdn2.iconfinder.com/data/icons/webstore/512/dollar_money_bag-512.png" style="width:15%;">
<h4>Account to Account Transfer</h4>
<center>
<?php if($message = Session::get('success')): ?>
    <p style="color:green"><span class="glyphicon glyphicon-ok"></span> <?php echo e($message); ?></p>
    <script> myFun();</script>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
    <p style="color:red"><span class="glyphicon glyphicon-remove"></span> <?php echo e($message); ?></p>
<?php endif; ?>
</center>
<hr>
</center>
<form action="<?php echo e(route('accounts.update', Auth::user()->id)); ?>" method="POST">
<?php echo e(method_field('PUT')); ?>

    <?php echo e(csrf_field()); ?>

  <div class="form-group col-md-8 col-md-offset-2">
    <label for="account">From Account</label>
    <select class="form-control" name="from_account">
    <option>Select</option>
    <?php $__currentLoopData = $accounts_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div><br>
  <div class="form-group col-md-8 col-md-offset-2">
    <label for="account">To Account</label>
    <select class="form-control" name="to_account">
    <option>Select</option>
    <?php $__currentLoopData = $accounts_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div><br>
  <div class="form-group col-md-8 col-md-offset-2">
    <label for="pwd">Transfer Amount</label>
    <input type="number" class="form-control" name="amount_transfer" placeholder="Enter Amount to be Transfer">
  </div>
  <div class="form-group col-md-8 col-md-offset-2">
    <label for="pwd">Description</label>
    <textarea type="text" class="form-control" name="description" placeholder="Enter Description"></textarea>
  </div>
  <center>
  <div class="form-group col-md-8 col-md-offset-5">
  <button type="submit" style="float:left;" class="btn btn-success">Submit</button>
  </center>
  </div>
</form>

</div>
<br><br>
</div>
</div><?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>